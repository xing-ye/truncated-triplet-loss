
## Transferring to Detection

We follow the evaluation setting in MoCo when trasferring to object detection.

### Instruction

1. Install [detectron2](https://github.com/facebookresearch/detectron2/blob/master/INSTALL.md).

1. Put dataset under "benchmarks/detection/datasets" directory,
   following the [directory structure](https://github.com/facebookresearch/detectron2/tree/master/datasets)
	 requried by detectron2.
