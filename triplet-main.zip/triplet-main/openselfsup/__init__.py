# from .version import __version__, short_version
__version__ = '0.3.0+1db69ec'
short_version = '0.3.0'
__all__ = ['__version__', 'short_version']
