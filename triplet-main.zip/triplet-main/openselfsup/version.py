# GENERATED VERSION FILE
# TIME: Sun Jan 31 14:34:47 2021

__version__ = '0.3.0+1db69ec'
short_version = '0.3.0'
