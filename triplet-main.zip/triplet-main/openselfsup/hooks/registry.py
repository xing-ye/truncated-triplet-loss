from openselfsup.utils import Registry

HOOKS = Registry('hook')
