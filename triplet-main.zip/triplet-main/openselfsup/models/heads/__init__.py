from .cls_head import ClsHead
from .triplet_loss_head import TripletLossHead
from .multi_cls_head import MultiClsHead
